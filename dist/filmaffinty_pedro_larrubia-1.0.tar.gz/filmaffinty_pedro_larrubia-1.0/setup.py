from setuptools import setup

setup(
    name="filmaffinty_pedro_larrubia",
    version="1.0",
    description="Segundo entregable",
    author="Pedro Larrubia Montes",
    author_email="alum.plarrubiam.2020@iesalixar.org",
    url="https://github.com/larrontee/",
    packages=["filmaffinty_pedro_larrubia"],
)
