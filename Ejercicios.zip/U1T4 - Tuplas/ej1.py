# Ejercicio 1
# Invierta la siguiente tupla
# tupla = (10, 20, 30, 40, 50)
# Resultado:
# (50, 40, 30, 20, 10)


