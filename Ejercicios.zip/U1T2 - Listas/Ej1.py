# Ejercicio 1:
# Invertir una lista dada
# Dado:
lista = [100, 200, 300, 400, 500]
# Resultado esperado:
# [500, 400, 300, 200, 100]

lista_inversa=lista[::-1]
print(lista_inversa)