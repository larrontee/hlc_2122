# Ejercicio 3
# Acceda al valor de la clave 'lengua'
# Dado:
diccionario = {"clase":{"estudiante":{"nombre":"Krilín","notas":{"matemáticas":20,"lengua":80}}}}
# Resultado:
# 80

print(diccionario["clase"]["estudiante"]["notas"]["lengua"])