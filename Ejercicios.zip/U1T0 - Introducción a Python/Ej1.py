#Escriba un programa para aceptar dos números del usuario y calcular la multiplicación

n=input("introduce un n")

m=input("introduce un n")

n = int(n)
m = int(m)


print(n*m)
