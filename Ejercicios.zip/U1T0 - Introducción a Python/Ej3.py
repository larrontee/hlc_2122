a="nombre"
b=" es "
c="ignatius"
print(a,b,c,sep=" ** ")