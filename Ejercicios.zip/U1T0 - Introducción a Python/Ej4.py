txt = "El número octal del número decimal {0} es {0:o}"

print(txt.format(8))