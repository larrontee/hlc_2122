#Acepte una lista de 5 números flotantes como entrada del usuario.

print("nuevo usuario")
input("Nombre")
