a = input("a = ")
b = input("b = ")
resultado = int(a)*int(b)

if resultado >= 1000:
    print(resultado)
else:print(int(a)+int(b))